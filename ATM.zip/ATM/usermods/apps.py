from django.apps import AppConfig


class UsermodsConfig(AppConfig):
    name = 'usermods'
