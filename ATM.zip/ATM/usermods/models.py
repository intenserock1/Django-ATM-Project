from django.db import models
from django.core.validators import MinLengthValidator
from django.contrib.auth.models import User

class ATMCard(models.Model):
    pin = models.CharField('Pin Number', max_length=4, validators=[MinLengthValidator(4)])
    issue_date = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    expiration_date = models.DateField(null=True, blank=True)
    balance = models.DecimalField(max_digits=9, decimal_places=2)
    card_status = (
        ('m', 'Maintenance'),
        ('a', 'Active'),
        ('e', 'Expired'),
        ('b', 'Blocked'),
    )

    status = models.CharField(
        max_length=1,
        choices=card_status,
        blank=True,
        default='m',
        help_text='Current card status',
    )

    class Meta:
        ordering = ['account']

    def __str__(self):
        return self.pin

class Account(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    account_number = models.CharField('Account Number', max_length=10, validators=[MinLengthValidator(10)])
    account_name = models.CharField(max_length=50)
    address = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    card = models.ForeignKey(ATMCard, null=True, on_delete=models.CASCADE)

    class Meta:
        ordering = ['id']

    def __str__(self):
        return self.account_name

class AtmMachine(models.Model):

    ATM_address = models.CharField(max_length=100)
    status = (
        ('o', 'Open'),
        ('c', 'Closed'),
        ('e', 'Empty'),
    )
    ATM_status = models.CharField(
        max_length=1,
        choices=status,
        blank=True,
        default='m',
        help_text='Current ATM Status',
    )

    last_refill = models.DateField(null=True, blank=True)
    next_refill = models.DateField(null=True, blank=True)

    min_balance_enquiry = models.IntegerField(blank=True, null=True)
    current_balance = models.IntegerField(blank=True, null=True)

    class Meta:
        ordering = ['ATM_address']

    def __str__(self):
        return self.ATM_address
