from django.contrib import admin

# Register your models here.

from .models import *
@admin.register(ATMCard)
class ATMCardAdmin(admin.ModelAdmin):
    list_display = ('pin', 'balance')

@admin.register(AtmMachine)
class AtmMachineAdmin(admin.ModelAdmin):
    list_display = ('ATM_address', 'ATM_status', 'last_refill', 'next_refill', 'min_balance_enquiry', 'current_balance')

admin.site.register(Account)
