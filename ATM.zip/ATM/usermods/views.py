from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models  import Group
#Create views
from .models import *
from .forms import CreateUserForm, TransferForm, WithdrawalForm, PINForm, PhoneForm
from .decorators import unauthenticated_user, allowed_users

@login_required(login_url='login')
def home(request):
    name = request.user.account.account_name
    addr = request.user.account.address
    num = request.user.account.account_number
    phone = request.user.account.phone_number
    issue = request.user.account.card.issue_date
    expire = request.user.account.card.expiration_date
    stat = request.user.account.card.status

    context = {'name':name, 'addr':addr, 'num':num, 'phone':phone,
    'issue':issue, 'expire':expire, 'stat':stat}
    return render(request, 'usermods/profile.html', context)

def registerPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()

        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                user = form.save()
                username = form.cleaned_data.get('username')
                group = Group.objects.get(name='customer')
                user.groups.add(group)
                Account.objects.create(
                     user=user
                )
                messages.success(request, 'Account was created for ' + username)
                return redirect('login')
        context = {'form':form}
        return render(request, 'usermods/register.html', context)

@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username or password is incorrect')
    context = {}
    return render(request, 'usermods/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def transfer(request):
    fromUser = request.user.account.card
    if request.method == 'POST':
        form = TransferForm(request.POST)

        if form.is_valid():
            if fromUser.pin == form.cleaned_data['card'].pin:
                return redirect('home')
            else:
                print("VALID")
                bal = form.save(commit=False)
                transfer_amount = form.cleaned_data['transfer_amount']
                toCard = form.cleaned_data['card']
                print(fromUser.balance)
                print(toCard.balance)
                print(fromUser.pin)
                print(toCard.pin)
                fromUser.balance = fromUser.balance - transfer_amount
                fromUser.save()
                toCard.balance = toCard.balance + transfer_amount
                print(fromUser.balance)
                print(toCard.balance)

                toCard.save()

                return redirect('home')
    else:
        form = TransferForm()
    context = {'form':form}
    return render(request, 'usermods/transfer.html', context)

@login_required(login_url='login')
def withdrawal(request):
    drawUser = request.user.account.card
    if request.method == 'POST':
        form = WithdrawalForm(request.POST)

        if form.is_valid():
            withdrawal_amount = form.cleaned_data['withdrawal_amount']
            withdraw = form.save(commit=False)
            drawUser.balance = drawUser.balance - withdrawal_amount
            drawUser.save()
            return redirect('home')
    else:
        form = WithdrawalForm()
    context = {'form':form}
    return render(request, 'usermods/withdrawal.html', context)

@login_required(login_url='login')
def balance(request):
    bal = request.user.account.card.balance
    context = {'bal':bal}
    return render(request, 'usermods/balance.html', context)

@login_required(login_url='login')
def transaction(request):
    return render(request, 'usermods/transaction.html')

@login_required(login_url='login')
def PINChange(request):
    pinUser = request.user.account.card
    if request.method == 'POST':
        form = PINForm(request.POST)

        if form.is_valid():
            newpin = form.cleaned_data['new_pin']
            pin = form.save(commit=False)
            pinUser.pin = newpin
            pinUser.save()
            return redirect('home')
    else:
        form = PINForm()
    context = {'form':form}
    return render(request, 'usermods/PINChange.html', context)

@login_required(login_url='login')
def PhoneChange(request):
    phoneUser = request.user.account
    if request.method == 'POST':
        form = PhoneForm(request.POST)

        if form.is_valid():
            newphone = form.cleaned_data['new_phone_number']
            phone = form.save(commit=False)
            phoneUser.phone_number = newphone
            phoneUser.save()
            return redirect('home')
    else:
        form = PhoneForm()
    context = {'form':form}
    return render(request, 'usermods/PhoneChange.html', context)
