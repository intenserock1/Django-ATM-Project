from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('register/', views.registerPage, name="register"),
    path('transfer/', views.transfer, name="transfer"),
    path('withdrawal/', views.withdrawal, name="withdrawal"),
    path('balance/', views.balance, name="balance"),
    path('PINChange/', views.PINChange, name="PINChange"),
    path('PhoneChange/', views.PhoneChange, name="PhoneChange"),
    path('transaction/', views.transaction, name="transaction"),
]
